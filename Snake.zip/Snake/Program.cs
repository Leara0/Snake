﻿using Snake;

Console.OutputEncoding = System.Text.Encoding.UTF8;

PlayGame.PlayTheGame();



/*
 * Suggested Changes from Brett
 * - add music
 * - make snake (caterpillar??) into an array
 * - make a pause screen? add instructions for how to pause if desired
 * - add ascii animation of snake/caterpillar
 * - changed snake print to for loop so you can color change the catepillar
 * - add in unicode characters
 * - obsticles
 *
 * my idea:
 * - red AND green apples, worth different points and both at the same time. Maybe red apples are closer to the edges??
*/
